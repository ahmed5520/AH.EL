#!/bin/python

###############################



                                   
print ("                                                                         \033[1;31m    `//`                    ") 
print ("                                                                           `:ods`                    ")
print ("                                                                          ./hy-`                     ") 
print ("                                                                        .+ys:.:/`                    ")
print ("                                                                      .:os/./+s:`                    ")
print ("                                                                    `-oh+.-ooo.`..                   ")
print ("                                                ```````           `:os+-.sy+.`-+s+                   ") 
print ("                                        `.-/+oo+oo+/:osso++:-.`  .oo/-.++s:`.+s+-`                   ") 
print ("                                    `-++sshhyyyoyy///:yo/sho+oo::yy-`/s+:..:+s/`                     ") 
print ("                                 `:oyhdososhoyssss++/-::/syoosoo/ho/sy:.`-++:`                       ") 
print ("                               -+yhhy+yysssso+/:.---.. `.-/ossosos/:yy+:+oo.                         ") 
print ("                             .oyddshdhhs/-.`               ``.-/ssooysooo/`                          ") 
print ("                           .oyysyssys:.                         `-+yso+ooh+.                         ") 
print ("                          :hdhshss+.  ./::::::::/:::::--:::::::::///ohddysdh+///.                    ") 
print ("                        `+mdoohh/`    /NmdmmmmdmNmmmmdhdmmmmmdddmNNNNNNNNNNNNNNM/                    ") 
print ("                      `ohsyhdy-\033[1;36m....../dddhyyyhhhhyyyyyyhhyhhsoooyhNhyyyhddddmdh-                    ") 
print ("                      \033[1;35m  +mhysdo\033[1;36m:hmmddmmmmmdh:`.hhhdy     ohhdh-  oymm.   \033[1;30m  -sshhs+                     ") 
print ("                    \033[1;35m   -mdyhmo\033[1;36m`mNNNddmNmmmdhy..hhdNh     /hdmd-  sydd.    \033[1;30m  .syoso-                    ") 
print ("                     \033[1;35m  ymdyyy`\033[1;36m+MNNNmmmmmmmdys/.hddmh     omNmh-  yyhd.     \033[1;30m  :+ymm+`                   ") 
print ("                    \033[1;35m  .mmhss- \033[1;36msNNNNmNNNmddhsso-mmmMh     yMMNm-  ssdd.      \033[1;30m  sysos.                   ") 
print ("                   \033[1;35m   +mmyy/  \033[1;36msMNh--------/shy-ddNMh     yMMMN-  ooyh.      \033[1;30m  -ysNyo                   ") 
print ("                    \033[1;35m  ommhs:  \033[1;36modmy        :hdy-mNMMh     sNMMN: `sdy+`      \033[1;30m  `mosyy                   ") 
print ("                    \033[1;35m  sddys-  \033[1;36msmms        /dNd:MNNMh     odNMM:  oyso`      \033[1;30m   d+yoy                   ") 
print ("                   \033[1;35m   +hmmh/  \033[1;36msmdo        /dNd:MmMMNdddddddmMM:  ssys`      \033[1;30m  `yyo+s                   ") 
print ("                    \033[1;35m  :ommy/  \033[1;36moys/ ```````+dNd:NmMMNMMNmNNhdNM: `+ohy.     \033[1;30m   -ysmh:                   ") 
print ("                    \033[1;35m  `dmmyy. \033[1;36m/soooyhoomddNNNd:NdNNhmNmmNNddmM: `+syy.    \033[1;30m    shhys-                   ") 
print ("                    \033[1;35m   -ddyyo`\033[1;36modhmddyyhdmmmmNd:NdNMNNmmNNNddmM: `ohhs`     \033[1;30m  :msods                    ") 
print ("                     \033[1;35m  `symmy-\033[1;36m+dmmmmmmmmmmmNMd:MddmmNmmdmdhdNM:  +hsy.    \033[1;30m  -hmosh.                    ") 
print ("                      \033[1;35m  .+ymmos\033[1;36mshmmmmmmddmmNMd:MNhyy:----sdNMM:  +ooo.   \033[1;30m  -hsydo-                     ") 
print ("                      \033[1;35m   .syhoh+\033[1;36msy:::-----ommy-NMNmy     sNMMM: `+sso` \033[1;30m  `+ddsyy`                      ") 
print ("                        \033[1;35m  .+ssy+oo`       \033[1;36m+mds-dNNMh     yNNNN:  +ohh.\033[1;30m `:ymdyo+-                       ") 
print ("                         \033[1;32m  `:osshhs-.     \033[1;36m+mdy-mmmmy     yNNNN:  /+yy/\033[1;32mymmyyy-`                        ") 
print ("                           \033[1;32m .oshyoyms-    \033[1;36m+yhy-dddhs     ydmNN:  ++hsdm\033[1;32myhoo-                          ") 
print ("                            \033[1;32m osshddyhoh+/ \033[1;36m+oyy-mmmhs     ohdmN/:+sohyhysy-                            ") 
print ("                            \033[1;32m    oyys+ohhhsdssssh+mmdyo....:sydddysoyshh++.`                             ") 
print ("                                 \033[1;32m  `./+hdoyyhsodds+ossdhoyyyyy+s+yyyh.                                ") 
print ("                                      .:-+ss/syshyyd+ysshsyyy+/:/++/`                                ") 
print ("                                             .-:-//oo:/:-/--.`                                        ") 
print ("			  \033[1;31m  ___ ___                     \033[1;31m __                    			     ")
print (" 			  \033[1;31m /   |   \  \033[1;32m _____     ____  \033[1;31m |  | __ \033[1;33m  ____  _______ 			     ")
print ("			 \033[1;31m /    ~    \ \033[1;32m \__  \  _/ ___\ \033[1;31m |  |/ / \033[1;33m_/ __ \ \_  __ \			     ")
print ("			 \033[1;31m \    Y    /  \033[1;32m / __ \_\  \___ \033[1;31m |    <  \033[1;33m\  ___/  |  | \/			     ")
print (" 			  \033[1;31m \___|_  /  \033[1;32m (____  / \___  >\033[1;31m |__|_ \  \033[1;33m\___  > |__|     			     ")
print ("       			        \033[1;31m \/        \033[1;32m \/      \/      \033[1;31m \/      \033[1;33m\/         			     ")








#print ("              ```        ```                             ---`                                        ") 
#print ("             `::-        -::.                            -::`                                        ") 
#print ("             `:--        -::. `..---.....`  `.........-. -::`    `...  `....-.--.    ..-----.`       ") 
#print ("             .::-```   ``-::. .::::/::::::``-::::::::::. -::`  `-:::. .::::::://:- `-::::::::`       ") 
#print ("             ./:::::::::-:::. `........-:/.`:::````````` -::.`.:::-`  -:/...``.//: `:::``````        ") 
#print ("             .//////:-::::::. .:/::://:://.`:::          -::--:::.    -::----:-::: `:::              ") 
#print ("             .//:        -::. .:::..--.:::.`:::          --:--:--.    -::---:---:: `:::              ") 
#print ("             .::-        -::. .:/:--.-.:/:.`:::........` -::` `--::`  -::-........ `:/:              ") 
#print ("                           ") 
#print ("                           ") 

