def kk(t):
   import sys, time
   for txt in t + "\n":
        sys.stdout.write(txt)
        sys.stdout.flush()
        time.sleep(9. / 2040)
a = "   \033[1;34m[ 11 ]\033[1;36m Facebook 		 \033[1;34m[ 22 ]\033[1;36m Youtube"
b = "  "
c = "  		\033[1;32m[ 33 ]\033[1;33m UPDATE                   \033[1;31m[ 00 ]Exit"
d = "  "
e = "  \033[1;35m==A=L=T=O=R=K=Y==>>.[ 1 ]\033[1;32m Install Metasploit ........>\033[1;35m [ 11 ]\033[1;32m DDOOS Attak "
f = "  "
g = "  \033[1;35m==A=L=T=O=R=K=Y==>>...[ 2 ]\033[1;32m Metasploit New ............>\033[1;35m [ 12 ]\033[1;32m Fiza card"
h = "  "
i = "  \033[1;35m==A=L=T=O=R=K=Y==>>.....[ 3 ]\033[1;32m Install payload .............>\033[1;35m [ 13 ]\033[1;32m Hack Acount "
j = "  "
k = "  \033[1;35m==A=L=T=O=R=K=Y==>>.......[ 4 ]\033[1;32m Hacking photo ................>\033[1;35m [ 14 ]\033[1;32m Louk Account"
l = "  "
m = "  \033[1;35m==A=L=T=O=R=K=Y==>>.........[ 5 ]\033[1;32m Open PORT .....................>\033[1;35m [ 15 ]\033[1;32m About IP "
n = "  "
o = "  \033[1;35m==A=L=T=O=R=K=Y==>>.........[ 6 ]\033[1;32m AHT T0olss ....................>\033[1;35m [ 16 ]\033[1;32m Geting the root  "
p = "  "
q = "  \033[1;35m==A=L=T=O=R=K=Y==>>.......[ 7 ]\033[1;32m Send SmS ......................>\033[1;35m [ 17 ]\033[1;32m New Osif  "
r = "  "
s = "  \033[1;35m==A=L=T=O=R=K=Y==>>.....[ 8 ]\033[1;32m Emails .......................>\033[1;35m [ 18 ]\033[1;32m Chat py termux  "
t = "  "
u = "  \033[1;35m==A=L=T=O=R=K=Y==>>...[ 9 ]\033[1;31m VIRUS AHT ....................>\033[1;35m [ 19 ]\033[1;32m Password List  "
v = "  "
w = "  \033[1;35m==A=L=T=O=R=K=Y==>>.[ 10 ]\033[1;32m Distributions Linux .........>\033[1;35m [ 20 ]\033[1;32m Problem Solving  "
x = "  "
kk(a)
kk(b)
kk(c)
kk(d)
kk(e)
kk(f)
kk(g)
kk(h)
kk(i)
kk(j)
kk(k)
kk(l)
kk(m)
kk(n)
kk(o)
kk(p)
kk(q)
kk(r)
kk(s)
kk(t)
kk(u)
kk(v)
kk(w)
kk(x)
